/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {7:1,8:5,4:5,0:-1,1:0,3:0,5:0,2:1,6:5};
});