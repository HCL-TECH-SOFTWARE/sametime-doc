define(function() {var keywords=[{w:"HCL",p:["p0"]},{w:"Sametime",p:["p0","p3","p5"]},{w:"API",p:["p0","p3","p5"]},{w:"Guide",p:["p0"]},{w:"Client",p:["p1","p2"]},{w:"Platform",p:["p1","p2"]},{w:"Technical",p:["p1"]},{w:"Preview",p:["p1"]},{w:"Documentation",p:["p2","p3","p5"]},{w:"(Technical",p:["p2"]},{w:"Preview)",p:["p2"]},{w:"Getting",p:["p3","p4"]},{w:"familiar",p:["p3"]},{w:"with",p:["p3"]},{w:"Started",p:["p4"]},{w:"Authorizing",p:["p6"]},{w:"your",p:["p6"]},{w:"Requests",p:["p6"]},{w:"Making",p:["p7"]},{w:"a",p:["p7"]},{w:"Request",p:["p7"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3];
ph["p1"]=[4, 5, 6, 7];
ph["p2"]=[4, 5, 8, 9, 10];
ph["p3"]=[11, 12, 13, 1, 2, 8];
ph["p4"]=[11, 14];
ph["p5"]=[1, 2, 8];
ph["p6"]=[15, 16, 17];
ph["p7"]=[18, 19, 20];
     return {
         keywords: keywords,
         ph: ph
     }
});
